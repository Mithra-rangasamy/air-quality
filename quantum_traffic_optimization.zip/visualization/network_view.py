"""
Microscopic road and vehicle visualization using Plotly and NetworkX.
Renders asphalt road corridors, lane dividers, physical vehicle queues (🚗, 🚙, 🚑),
moving green-wave traffic, and pedestrian crosswalk clusters (🚶).
"""

from typing import Optional, Dict, Any, List, Tuple
import plotly.graph_objects as go
import numpy as np
import config
from simulation.network import TrafficNetwork
from emergency.corridor import EmergencyCorridor

def create_network_figure(
    network: TrafficNetwork,
    corridor: Optional[EmergencyCorridor] = None,
    show_vehicles: bool = True,
    show_pedestrians: bool = True
) -> go.Figure:
    """
    Renders an interactive microscopic view of the 2x3 urban road network:
    - Wide asphalt road corridors with lane markings
    - Individual queued and moving vehicles (🚗, 🚙, 🚕, 🚐) positioned on lanes
    - Emergency Ambulance (🚑) with priority halo
    - Pedestrian waiting clusters (🚶) on crosswalk curbs
    - Intersection signal status lights (🟢 Green / 🔴 Red)
    """
    pos = {
        'A': np.array([0.0, 1.0]), 'B': np.array([1.3, 1.0]), 'C': np.array([2.6, 1.0]),
        'D': np.array([0.0, 0.0]), 'E': np.array([1.3, 0.0]), 'F': np.array([2.6, 0.0])
    }

    ambulance_node = corridor.get_current_ambulance_node() if (corridor and corridor.is_active) else None
    corridor_path = corridor.ambulance_path if (corridor and corridor.is_active) else []

    fig = go.Figure()

    # --------------------------------------------------------------------------
    # 1. Asphalt Road Corridors (Wide background lines)
    # --------------------------------------------------------------------------
    for u, v in network.graph.edges():
        is_closed = network.is_road_closed(u, v)
        p0, p1 = pos[u], pos[v]

        # Check if corridor edge
        is_corridor = False
        if corridor_path and len(corridor_path) > 1:
            for k in range(len(corridor_path) - 1):
                if (u == corridor_path[k] and v == corridor_path[k+1]) or (v == corridor_path[k] and u == corridor_path[k+1]):
                    is_corridor = True
                    break

        road_color = '#1e293b' # Dark asphalt
        road_width = 16
        if is_closed:
            road_color = '#64748b'
        elif is_corridor:
            road_color = '#0284c7' # Cyan highlight for green corridor

        # Asphalt base
        fig.add_trace(go.Scatter(
            x=[p0[0], p1[0]], y=[p0[1], p1[1]],
            mode='lines',
            line=dict(width=road_width, color=road_color),
            hoverinfo='skip',
            showlegend=False
        ))

        # White/Yellow center dashed lane divider
        lane_dash = 'dot' if not is_closed else 'dash'
        fig.add_trace(go.Scatter(
            x=[p0[0], p1[0]], y=[p0[1], p1[1]],
            mode='lines',
            line=dict(width=2, color='#f8fafc' if not is_closed else '#ef4444', dash=lane_dash),
            hoverinfo='text',
            text=f"Road {u} ↔ {v} ({'⛔ CLOSED' if is_closed else 'ACTIVE'})",
            showlegend=False
        ))

    # --------------------------------------------------------------------------
    # 2. Microscopic Vehicles (🚗, 🚙, 🚕, 🚑) on Road Segments
    # --------------------------------------------------------------------------
    if show_vehicles:
        veh_x, veh_y, veh_text, veh_colors, veh_symbols = [], [], [], [], []

        for node_id in config.INTERSECTION_IDS:
            state = network.get_state(node_id)
            queue = state.queue_length
            signal = state.signal_state
            is_emg = (ambulance_node == node_id)

            # Find upstream incoming edges to distribute queued vehicles
            neighbors = list(network.graph.neighbors(node_id))
            if not neighbors:
                continue

            cars_placed = 0
            cars_per_edge = max(1, queue // len(neighbors))

            for nbr in neighbors:
                if network.is_road_closed(node_id, nbr):
                    continue
                p_dst = pos[node_id]
                p_src = pos[nbr]
                vec = p_dst - p_src
                dist = np.linalg.norm(vec)
                unit_vec = vec / dist if dist > 0 else np.array([1.0, 0.0])
                ortho_vec = np.array([-unit_vec[1], unit_vec[0]]) * 0.035 # Lane offset

                # Place queued cars backed up from stop-line
                num_on_this_leg = min(cars_per_edge, queue - cars_placed)
                for c_idx in range(num_on_this_leg):
                    offset_dist = 0.08 + (c_idx * 0.055)
                    if offset_dist >= dist * 0.85:
                        break # Don't spill over into upstream node

                    car_pos = p_dst - (unit_vec * offset_dist) + ortho_vec
                    veh_x.append(car_pos[0])
                    veh_y.append(car_pos[1])

                    # Color based on signal: Red = stopped queue, Green = flowing
                    if signal == 1:
                        veh_colors.append('#22c55e') # Green (flowing car)
                        veh_text.append(f"🚙 Flowing Car at {node_id} (Discharging)")
                    else:
                        veh_colors.append('#ef4444') # Red (stopped queue)
                        veh_text.append(f"🚗 Queued Car #{c_idx+1} waiting at {node_id}")

                    veh_symbols.append('square')
                    cars_placed += 1

        # Render regular vehicles
        if veh_x:
            fig.add_trace(go.Scatter(
                x=veh_x, y=veh_y,
                mode='markers',
                marker=dict(
                    size=10,
                    color=veh_colors,
                    symbol=veh_symbols,
                    line=dict(width=1, color='#0f172a')
                ),
                hoverinfo='text',
                hovertext=veh_text,
                name='Vehicles (Cars)',
                showlegend=True
            ))

        # ----------------------------------------------------------------------
        # Ambulance (🚑) Special Prominent Marker
        # ----------------------------------------------------------------------
        if ambulance_node:
            amb_pos = pos[ambulance_node] + np.array([0.0, 0.06])
            fig.add_trace(go.Scatter(
                x=[amb_pos[0]], y=[amb_pos[1]],
                mode='markers+text',
                marker=dict(
                    size=22,
                    color='#38bdf8', # Bright Blue
                    symbol='diamond',
                    line=dict(width=3, color='#eab308') # Golden flashing border
                ),
                text=["🚑 AMBULANCE"],
                textposition="top center",
                textfont=dict(size=12, color='#0284c7', family='Arial Black'),
                hoverinfo='text',
                hovertext=f"🚑 Emergency Ambulance Priority Vehicle at Node {ambulance_node}",
                name='Ambulance 🚑',
                showlegend=True
            ))

    # --------------------------------------------------------------------------
    # 3. Pedestrians (🚶) Waiting on Sidewalk Corners
    # --------------------------------------------------------------------------
    if show_pedestrians:
        ped_x, ped_y, ped_text, ped_sizes = [], [], [], []
        for node_id in config.INTERSECTION_IDS:
            state = network.get_state(node_id)
            demand = state.pedestrian_demand
            if demand > 0:
                # Sidewalk corner offset
                corner_pos = pos[node_id] + np.array([0.08, -0.08])
                ped_x.append(corner_pos[0])
                ped_y.append(corner_pos[1])
                ped_text.append(f"🚶 {demand} Pedestrians waiting to cross at {node_id}")
                # Marker size scaled by demand
                ped_sizes.append(min(22, 10 + demand))

        if ped_x:
            fig.add_trace(go.Scatter(
                x=ped_x, y=ped_y,
                mode='markers+text',
                marker=dict(
                    size=ped_sizes,
                    color='#f59e0b', # Amber / Pedestrian yellow
                    symbol='circle',
                    line=dict(width=2, color='#78350f')
                ),
                text=[f"🚶×{network.get_state(n).pedestrian_demand}" for n in config.INTERSECTION_IDS if network.get_state(n).pedestrian_demand > 0],
                textposition="bottom right",
                textfont=dict(size=10, color='#b45309'),
                hoverinfo='text',
                hovertext=ped_text,
                name='Pedestrians 🚶',
                showlegend=True
            ))

    # --------------------------------------------------------------------------
    # 4. Intersections & Signal Lights (🟢 / 🔴)
    # --------------------------------------------------------------------------
    node_x, node_y, node_colors, node_labels, hover_texts = [], [], [], [], []

    for node in config.INTERSECTION_IDS:
        p = pos[node]
        node_x.append(p[0])
        node_y.append(p[1])

        state = network.get_state(node)
        meta = config.INTERSECTION_METADATA[node]

        if state.signal_state == 1:
            node_colors.append('#22c55e') # Green signal
            sig_icon = "🟢"
            sig_text = "GREEN (Priority Flow)"
        else:
            node_colors.append('#ef4444') # Red signal
            sig_icon = "🔴"
            sig_text = "RED (Pedestrian Walk)"

        prefix = "🏥 " if meta.get('is_hospital') else ("🚑 " if ambulance_node == node else "")
        node_labels.append(f"<b>{prefix}{node} {sig_icon}</b>")

        hover_info = (
            f"<b>Intersection {node}: {meta['name']}</b><br>"
            f"Signal: {sig_text}<br>"
            f"Queue: {state.queue_length} / {state.capacity} cars<br>"
            f"Density: {state.traffic_density} vehicles<br>"
            f"Pedestrians: {state.pedestrian_demand} waiting<br>"
            f"Accident Severity: {int(state.accident_severity * 100)}%<br>"
            f"Corridor Priority: {'🚨 ACTIVE' if state.emergency_priority else 'None'}"
        )
        hover_texts.append(hover_info)

    fig.add_trace(go.Scatter(
        x=node_x, y=node_y,
        mode='markers+text',
        text=node_labels,
        textposition="top center",
        textfont=dict(size=14, color='#0f172a', family='Arial Black'),
        hoverinfo='text',
        hovertext=hover_texts,
        marker=dict(
            size=36,
            color=node_colors,
            line=dict(color='#0f172a', width=3)
        ),
        name='Traffic Signals',
        showlegend=True
    ))

    # Layout Aesthetics
    fig.update_layout(
        title=dict(text="🚦 Microscopic Traffic Simulation: Roads, Vehicles & Signals", font=dict(size=16)),
        hovermode='closest',
        margin=dict(b=25, l=25, r=25, t=50),
        xaxis=dict(showgrid=False, zeroline=False, showticklabels=False, range=[-0.35, 2.95]),
        yaxis=dict(showgrid=False, zeroline=False, showticklabels=False, range=[-0.35, 1.35]),
        plot_bgcolor='#f1f5f9',
        height=420,
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1)
    )

    return fig
