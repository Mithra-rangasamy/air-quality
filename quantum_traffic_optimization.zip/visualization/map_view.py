"""
Geographical map visualization using Folium and OpenStreetMap with microscopic vehicle & road rendering.
"""

from typing import Optional, Dict, Any
import folium
from folium import plugins
import numpy as np
import config
from simulation.network import TrafficNetwork
from emergency.corridor import EmergencyCorridor

def create_folium_map(
    network: TrafficNetwork,
    corridor: Optional[EmergencyCorridor] = None,
    show_vehicles: bool = True
) -> folium.Map:
    """
    Renders an OpenStreetMap geographical visualization showing:
    - Roads with asphalt lane styling and dynamic congestion heat
    - Microscopic vehicles (queued cars 🔴 vs moving cars 🟢) along roads
    - Active Emergency Green Corridor route in vibrant cyan
    - Emergency Ambulance (🚑) and Trauma Hospital (🏥)
    - Pedestrian waiting clusters at intersections
    """
    center_lat = 51.5042
    center_lon = -0.1235

    m = folium.Map(
        location=[center_lat, center_lon],
        zoom_start=15,
        tiles="OpenStreetMap",
        control_scale=True
    )

    ambulance_node = corridor.get_current_ambulance_node() if (corridor and corridor.is_active) else None
    corridor_path = corridor.ambulance_path if (corridor and corridor.is_active) else []

    # 1. Render Road Segments
    for u, v in network.graph.edges():
        is_closed = network.is_road_closed(u, v)
        meta_u = config.INTERSECTION_METADATA[u]
        meta_v = config.INTERSECTION_METADATA[v]
        coords = [[meta_u['lat'], meta_u['lon']], [meta_v['lat'], meta_v['lon']]]

        is_corridor_edge = False
        if corridor_path and len(corridor_path) > 1:
            for k in range(len(corridor_path) - 1):
                if (u == corridor_path[k] and v == corridor_path[k+1]) or (v == corridor_path[k] and u == corridor_path[k+1]):
                    is_corridor_edge = True
                    break

        if is_closed:
            color = "#475569"
            weight = 4
            dash_array = "6, 12"
            tooltip = f"⛔ ROAD CLOSED: {u} ↔ {v}"
        elif is_corridor_edge:
            color = "#00D2FF" # Vibrant Cyan
            weight = 9
            dash_array = None
            tooltip = f"🚨 EMERGENCY GREEN CORRIDOR: {u} ↔ {v}"
        else:
            state_u = network.get_state(u)
            state_v = network.get_state(v)
            avg_q = (state_u.queue_length + state_v.queue_length) / 2.0
            if avg_q > 18:
                color = "#ef4444"
            elif avg_q > 8:
                color = "#f97316"
            else:
                color = "#10b981"
            weight = 6
            dash_array = None
            tooltip = f"Avenue {u} ↔ {v} (Avg Queue: {avg_q:.1f} cars)"

        folium.PolyLine(
            locations=coords,
            color=color,
            weight=weight,
            dash_array=dash_array,
            opacity=0.85,
            tooltip=tooltip
        ).add_to(m)

        # 2. Render Microscopic Vehicles along the Road Segment
        if show_vehicles and not is_closed:
            state_v = network.get_state(v)
            num_cars = min(5, state_v.queue_length // 2)
            if num_cars > 0:
                p_u = np.array([meta_u['lat'], meta_u['lon']])
                p_v = np.array([meta_v['lat'], meta_v['lon']])
                for c in range(1, num_cars + 1):
                    frac = 1.0 - (c * 0.14)
                    car_lat_lon = p_u + frac * (p_v - p_u)
                    car_color = "#22c55e" if state_v.signal_state == 1 else "#ef4444"
                    folium.CircleMarker(
                        location=[car_lat_lon[0], car_lat_lon[1]],
                        radius=4,
                        color="#0f172a",
                        weight=1,
                        fill=True,
                        fill_color=car_color,
                        fill_opacity=0.9,
                        tooltip=f"🚗 Vehicle queuing toward Node {v}"
                    ).add_to(m)

    # 3. Render Intersection Markers
    for node_id, state in network.intersections.items():
        meta = config.INTERSECTION_METADATA[node_id]
        loc = [meta['lat'], meta['lon']]

        signal_str = "🟢 GREEN (Priority)" if state.signal_state == 1 else "🔴 RED (Cross)"
        popup_html = f"""
        <div style='font-family: sans-serif; min-width: 170px;'>
            <h4 style='margin: 0 0 5px 0;'>Node {node_id}: {meta['name']}</h4>
            <b>Signal State:</b> {signal_str}<br>
            <b>Queue Backlog:</b> {state.queue_length} / {state.capacity} cars<br>
            <b>Traffic Density:</b> {state.traffic_density}<br>
            <b>Pedestrians Waiting:</b> {state.pedestrian_demand}<br>
            <b>Accident Severity:</b> {int(state.accident_severity * 100)}%<br>
            <b>Emergency Priority:</b> {'YES 🚨' if state.emergency_priority else 'NO'}
        </div>
        """

        if ambulance_node == node_id:
            folium.Marker(
                location=loc,
                popup=folium.Popup(f"<b>🚑 AMBULANCE IN TRANSIT</b><br>Currently clearing Node {node_id} ({meta['name']})", max_width=250),
                tooltip="🚑 Ambulance (Priority Vehicle)",
                icon=folium.Icon(color="blue", icon="plus-sign", prefix="glyphicon")
            ).add_to(m)
        elif meta.get('is_hospital', False):
            folium.Marker(
                location=loc,
                popup=folium.Popup(f"<b>🏥 ST THOMAS HOSPITAL</b><br>Emergency Trauma Destination", max_width=250),
                tooltip="🏥 Trauma Hospital",
                icon=folium.Icon(color="red", icon="heart", prefix="glyphicon")
            ).add_to(m)
        else:
            marker_color = "#22c55e" if state.signal_state == 1 else "#ef4444"
            folium.CircleMarker(
                location=loc,
                radius=11,
                color="#0f172a",
                weight=2,
                fill=True,
                fill_color=marker_color,
                fill_opacity=0.9,
                tooltip=f"Node {node_id}: {signal_str} (Queue: {state.queue_length})",
                popup=folium.Popup(popup_html, max_width=280)
            ).add_to(m)

    return m
