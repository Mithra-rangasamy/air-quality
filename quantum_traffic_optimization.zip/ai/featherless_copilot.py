"""
Featherless AI Copilot for Quantum Urban Traffic Optimization.
Interacts with Featherless AI's OpenAI-compatible API to provide:
1. Natural Language Incident Dispatch & Action Parsing
2. Quantum Decision Explainability (XAI) for Civic Transparency
3. Autonomous QUBO Policy Weight Calibration
"""

import os
import json
import re
from typing import Dict, Any, List, Optional
import requests
import config

DEFAULT_FEATHERLESS_MODEL = "meta-llama/Meta-Llama-3.1-8B-Instruct"
FEATHERLESS_API_BASE = "https://api.featherless.ai/v1"

class FeatherlessCopilot:
    def __init__(self, api_key: Optional[str] = None, model: str = DEFAULT_FEATHERLESS_MODEL):
        self.api_key = api_key or os.getenv("FEATHERLESS_API_KEY")
        self.model = model
        self.base_url = FEATHERLESS_API_BASE

    def has_api_key(self) -> bool:
        return bool(self.api_key and self.api_key.strip().startswith("sk-") or (self.api_key and len(self.api_key) > 8))

    def _call_llm(self, system_prompt: str, user_prompt: str, max_tokens: int = 500, temperature: float = 0.2) -> Optional[str]:
        """Calls Featherless AI API with timeout and error handling."""
        if not self.has_api_key():
            return None

        headers = {
            "Authorization": f"Bearer {self.api_key.strip()}",
            "Content-Type": "application/json"
        }
        payload = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt}
            ],
            "max_tokens": max_tokens,
            "temperature": temperature
        }

        try:
            resp = requests.post(
                f"{self.base_url}/chat/completions",
                headers=headers,
                json=payload,
                timeout=12
            )
            if resp.status_code == 200:
                data = resp.json()
                return data["choices"][0]["message"]["content"]
            else:
                return None
        except Exception:
            return None

    def parse_incident_report(self, text: str) -> Dict[str, Any]:
        """
        Extracts structured operational commands from free-form operator text.
        Returns actions: congestion, accident, road_closure, ambulance_dispatch.
        """
        system_prompt = """You are an AI Urban Traffic Dispatcher for London Westminster grid.
Intersections: A (Parliament Sq), B (Whitehall), C (Trafalgar Sq), D (Westminster Bridge), E (Embankment), F (St Thomas Hospital).
Edges: A-B, B-C, D-E, E-F, A-D, B-E, C-F.

Analyze the user's traffic report and output ONLY a JSON object with this schema:
{
  "trigger_congestion": ["B"], // list of nodes with sudden queue surges, or []
  "trigger_accident": {"node": "B", "severity": 0.75}, // or null
  "trigger_closure": ["B", "C"], // edge pair [u, v] to close, or null
  "dispatch_ambulance": {"origin": "A", "destination": "F"}, // or null
  "summary": "Brief executive summary of incident actions taken"
}"""
        raw_resp = self._call_llm(system_prompt, text, max_tokens=300)

        if raw_resp:
            try:
                # Extract JSON from response
                match = re.search(r'\{.*\}', raw_resp, re.DOTALL)
                if match:
                    return json.loads(match.group(0))
            except Exception:
                pass

        # Intelligent Rule-Based Fallback if API key not present or call fails
        return self._heuristic_incident_parse(text)

    def explain_quantum_decision(
        self,
        step: int,
        decisions: Dict[str, int],
        queue_summary: Dict[str, int],
        pedestrian_summary: Dict[str, int],
        corridor_active: bool,
        ambulance_loc: Optional[str],
        qubo_cost: float
    ) -> str:
        """
        Generates a transparent civic welfare audit explaining why QAOA selected the signal states.
        """
        green_nodes = [node for node, bit in decisions.items() if bit == 1]
        red_nodes = [node for node, bit in decisions.items() if bit == 0]

        user_prompt = f"""
Step: {step}
Signals Assigned Green: {green_nodes}
Signals Assigned Red (Cross/Pedestrian Walk): {red_nodes}
Queue Backlog: {queue_summary}
Pedestrian Demand: {pedestrian_summary}
Emergency Corridor Active: {corridor_active} (Ambulance currently at: {ambulance_loc})
QUBO Energy Cost: {qubo_cost}
Explain the public welfare and traffic physics justification in 3-4 sentences.
"""
        system_prompt = """You are a Quantum Civic Audit AI for metropolitan traffic control.
Explain the mathematical and social welfare rationale behind the QAOA quantum signal decisions clearly and concisely to city officials. Focus on queue clearance, pedestrian safety, emergency transit speed, and reduced carbon emissions."""

        llm_explanation = self._call_llm(system_prompt, user_prompt, max_tokens=350)
        if llm_explanation:
            return llm_explanation.strip()

        # Deterministic civic explanation fallback
        green_str = ", ".join(green_nodes) if green_nodes else "None"
        red_str = ", ".join(red_nodes) if red_nodes else "None"
        emg_note = f" Priority was enforced for the active ambulance at Node {ambulance_loc}." if corridor_active else ""
        return (
            f"**QAOA Quantum Decision Audit (Step {step}):** "
            f"The quantum optimizer assigned green light to intersections **{green_str}** to clear critical queues "
            f"and sustain high arterial throughput while holding cross-traffic at **{red_str}**.{emg_note} "
            f"This minimized uncoordinated braking cycles, preserving pedestrian crossing safety and reducing estimated CO2 emissions."
        )

    def recommend_policy_weights(self, policy_name: str) -> Dict[str, float]:
        """Adjusts QUBO social welfare weights to match municipal priorities."""
        policies = {
            "Balanced Social Welfare (Default)": config.QUBO_WEIGHTS.copy(),
            "Peak Commuter Rush Hour (Max Throughput)": {
                'w_wait': 2.0, 'w_queue': 2.2, 'w_density': 1.5, 'w_ped': 0.6,
                'w_emg': 12.0, 'w_thru': 1.8, 'w_switch': 0.2, 'p_conflict': 4.5
            },
            "Clean Air & Low Emission Zone (Min Fuel/CO2)": {
                'w_wait': 1.0, 'w_queue': 1.2, 'w_density': 1.0, 'w_ped': 1.2,
                'w_emg': 12.0, 'w_thru': 0.6, 'w_switch': 2.0, 'p_conflict': 4.0
            },
            "Pedestrian Safety & Active Travel (School / Event)": {
                'w_wait': 0.8, 'w_queue': 0.9, 'w_density': 0.8, 'w_ped': 3.5,
                'w_emg': 12.0, 'w_thru': 0.5, 'w_switch': 0.5, 'p_conflict': 3.0
            },
            "Maximum Emergency Transit (Life First)": {
                'w_wait': 0.8, 'w_queue': 1.0, 'w_density': 0.8, 'w_ped': 1.0,
                'w_emg': 25.0, 'w_thru': 0.6, 'w_switch': 0.3, 'p_conflict': 5.0
            }
        }
        return policies.get(policy_name, config.QUBO_WEIGHTS.copy())

    def _heuristic_incident_parse(self, text: str) -> Dict[str, Any]:
        """Deterministic keyword parser matching London Westminster nodes."""
        t = text.lower()
        res = {
            "trigger_congestion": [],
            "trigger_accident": None,
            "trigger_closure": None,
            "dispatch_ambulance": None,
            "summary": "Heuristic dispatch based on incident keywords."
        }

        # Check for accident
        if any(w in t for w in ["accident", "crash", "collision", "blocked", "incident"]):
            # Identify node: check landmark names first, then isolated letter IDs
            acc_node = 'B'
            if "whitehall" in t or "downing" in t:
                acc_node = 'B'
            elif "trafalgar" in t:
                acc_node = 'C'
            elif "parliament" in t:
                acc_node = 'A'
            elif "bridge" in t:
                acc_node = 'D'
            elif "embankment" in t:
                acc_node = 'E'
            elif "hospital" in t:
                acc_node = 'F'
            else:
                match = re.search(r'\bnode\s+([a-f])\b|\bat\s+([a-f])\b|\b([a-f])\b', t)
                if match:
                    acc_node = (match.group(1) or match.group(2) or match.group(3)).upper()
            res["trigger_accident"] = {"node": acc_node, "severity": 0.75}

        # Check for closure
        if any(w in t for w in ["close", "closure", "shut", "blocked road"]):
            res["trigger_closure"] = ["B", "C"]

        # Check for congestion
        if any(w in t for w in ["congestion", "traffic", "jam", "heavy", "surge"]):
            cong = []
            if "whitehall" in t or "downing" in t or re.search(r'\b[b]\b', t):
                cong.append('B')
            if "embankment" in t or re.search(r'\b[e]\b', t):
                cong.append('E')
            if "trafalgar" in t or re.search(r'\b[c]\b', t):
                cong.append('C')
            res["trigger_congestion"] = cong or ['B', 'E']

        # Check for ambulance / emergency
        if any(w in t for w in ["ambulance", "emergency", "paramedic", "patient", "dispatch"]):
            res["dispatch_ambulance"] = {"origin": "A", "destination": "F"}

        res["summary"] = f"Processed incident prompt: {text[:70]}..."
        return res
