"""
Featherless AI Copilot package for natural language traffic dispatch,
quantum decision explainability (XAI), and autonomous policy tuning.
"""
