"""
Unit tests for Featherless AI Copilot (NLP parsing, XAI generation, policy tuning)
and microscopic vehicle visualization.
"""

import unittest
import os
import config
from simulation.network import TrafficNetwork
from ai.featherless_copilot import FeatherlessCopilot
from visualization.network_view import create_network_figure
from visualization.map_view import create_folium_map
from emergency.corridor import EmergencyCorridor

class TestFeatherlessAndVisualization(unittest.TestCase):
    def setUp(self):
        config.set_seed()
        self.net = TrafficNetwork()
        self.corridor = EmergencyCorridor(self.net)
        self.copilot = FeatherlessCopilot(api_key=None) # Tests offline/heuristic fallback

    def test_copilot_heuristic_accident_parsing(self):
        text = "Major vehicle collision on Whitehall blocking lanes. Ambulance needed from A to F."
        res = self.copilot.parse_incident_report(text)

        self.assertIsNotNone(res.get("trigger_accident"))
        self.assertEqual(res["trigger_accident"]["node"], "B")
        self.assertIsNotNone(res.get("dispatch_ambulance"))
        self.assertEqual(res["dispatch_ambulance"]["origin"], "A")
        self.assertEqual(res["dispatch_ambulance"]["destination"], "F")

    def test_copilot_heuristic_closure_parsing(self):
        text = "Protest near Trafalgar Square, please close the road between B and C."
        res = self.copilot.parse_incident_report(text)

        self.assertIsNotNone(res.get("trigger_closure"))
        self.assertEqual(res["trigger_closure"], ["B", "C"])

    def test_copilot_xai_explanation(self):
        decisions = {'A': 1, 'B': 1, 'C': 0, 'D': 0, 'E': 1, 'F': 0}
        queues = {'A': 12, 'B': 18, 'C': 4, 'D': 3, 'E': 14, 'F': 2}
        peds = {'A': 2, 'B': 1, 'C': 15, 'D': 1, 'E': 3, 'F': 0}

        explanation = self.copilot.explain_quantum_decision(
            step=1,
            decisions=decisions,
            queue_summary=queues,
            pedestrian_summary=peds,
            corridor_active=False,
            ambulance_loc=None,
            qubo_cost=-45.2
        )

        self.assertTrue(len(explanation) > 40)
        self.assertIn("QAOA", explanation)
        self.assertIn("green", explanation.lower())

    def test_copilot_policy_tuning(self):
        default_w = self.copilot.recommend_policy_weights("Balanced Social Welfare (Default)")
        clean_air_w = self.copilot.recommend_policy_weights("Clean Air & Low Emission Zone (Min Fuel/CO2)")

        self.assertGreater(clean_air_w['w_switch'], default_w['w_switch'])

    def test_network_figure_with_vehicles_and_pedestrians(self):
        self.net.get_state('A').queue_length = 8
        self.net.get_state('C').pedestrian_demand = 6
        self.corridor.trigger_emergency('A', 'F')

        fig = create_network_figure(self.net, self.corridor, show_vehicles=True, show_pedestrians=True)
        # Figure should contain traces for roads, lane markings, vehicles, ambulance, pedestrians, signals
        self.assertGreaterEqual(len(fig.data), 4)

    def test_folium_map_with_vehicles(self):
        self.net.get_state('B').queue_length = 10
        folium_map = create_folium_map(self.net, self.corridor, show_vehicles=True)
        self.assertIsNotNone(folium_map)

if __name__ == '__main__':
    unittest.main()
