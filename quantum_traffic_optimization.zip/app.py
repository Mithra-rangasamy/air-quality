"""
Quantum-Enhanced Adaptive Urban Traffic Optimization
Hybrid Quantum-Classical Traffic Optimization for Social Welfare
Featuring Featherless AI Civic Copilot & Microscopic Vehicle Visualization
Hackathon MVP Interactive Dashboard
"""

import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import plotly.express as px
import time
import os

import config
from simulation.network import TrafficNetwork
from simulation.state import IntersectionState
from simulation.traffic import TrafficSimulator
from simulation.pedestrians import PedestrianManager
from simulation.events import EventManager
from optimization.qubo import TrafficQUBO
from optimization.ising import qubo_to_ising, to_qiskit_pauli_op
from optimization.qaoa_qiskit import QAOAOptimizerQiskit
from optimization.qaoa_pennylane import QAOAOptimizerPennyLane
from optimization.classical import FixedTimeController, RuleBasedAdaptiveController
from quantum.aer_backend import AerBackendManager
from quantum.ibm_backend import IBMQuantumManager
from emergency.corridor import EmergencyCorridor
from visualization.map_view import create_folium_map
from visualization.network_view import create_network_figure
from metrics.evaluation import MetricsEvaluator
from ai.featherless_copilot import FeatherlessCopilot, DEFAULT_FEATHERLESS_MODEL

try:
    from streamlit_folium import st_folium
    FOLIUM_AVAILABLE = True
except ImportError:
    FOLIUM_AVAILABLE = False

# --- Streamlit Page Setup ---
st.set_page_config(
    page_title="Quantum Traffic Optimization & AI Copilot | Quantexa MVP",
    page_icon="🚦",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for styling
st.markdown("""
<style>
    .main-title {
        font-size: 2.2rem;
        font-weight: 800;
        color: #1e293b;
        margin-bottom: 0.1rem;
    }
    .sub-title {
        font-size: 1.15rem;
        font-weight: 500;
        color: #0284c7;
        margin-bottom: 1.2rem;
    }
    .badge-quantum {
        background-color: #e0f2fe;
        color: #0369a1;
        padding: 4px 8px;
        border-radius: 6px;
        font-weight: 600;
        font-size: 0.85rem;
    }
    .badge-classical {
        background-color: #fef3c7;
        color: #b45309;
        padding: 4px 8px;
        border-radius: 6px;
        font-weight: 600;
        font-size: 0.85rem;
    }
    .badge-emergency {
        background-color: #fee2e2;
        color: #b91c1c;
        padding: 4px 8px;
        border-radius: 6px;
        font-weight: 700;
        font-size: 0.85rem;
    }
    .badge-ai {
        background-color: #f3e8ff;
        color: #7e22ce;
        padding: 4px 8px;
        border-radius: 6px;
        font-weight: 700;
        font-size: 0.85rem;
    }
    .chat-bubble {
        background-color: #f8fafc;
        border-left: 4px solid #7e22ce;
        padding: 12px 16px;
        border-radius: 6px;
        margin-bottom: 10px;
    }
</style>
""", unsafe_allow_html=True)

# --- Session State Initialization ---
if 'initialized' not in st.session_state:
    config.set_seed()
    st.session_state.network = TrafficNetwork()
    st.session_state.ped_mgr = PedestrianManager(st.session_state.network)
    st.session_state.simulator = TrafficSimulator(st.session_state.network, st.session_state.ped_mgr)
    st.session_state.events = EventManager(st.session_state.network)
    st.session_state.corridor = EmergencyCorridor(st.session_state.network)

    # Quantum & Classical Solvers
    st.session_state.aer_manager = AerBackendManager()
    st.session_state.ibm_manager = IBMQuantumManager()
    st.session_state.qaoa_qiskit = QAOAOptimizerQiskit(reps=config.QAOA_REPS, shots=config.QAOA_SHOTS)
    st.session_state.qaoa_pennylane = QAOAOptimizerPennyLane(reps=config.QAOA_REPS, shots=config.QAOA_SHOTS)
    st.session_state.fixed_controller = FixedTimeController(st.session_state.network)
    st.session_state.rule_controller = RuleBasedAdaptiveController(st.session_state.network)

    # Featherless AI Copilot
    st.session_state.featherless_copilot = FeatherlessCopilot()
    st.session_state.custom_qubo_weights = config.QUBO_WEIGHTS.copy()
    st.session_state.copilot_history = []
    st.session_state.last_xai_explanation = None

    # Metrics Trackers
    st.session_state.metrics_classical = MetricsEvaluator(mode_name="Classical (Fixed-Time)")
    st.session_state.metrics_quantum = MetricsEvaluator(mode_name="Quantum QAOA (Hybrid)")

    # Execution State
    st.session_state.step = 0
    st.session_state.last_mode = "None"
    st.session_state.last_decisions = {node: 0 for node in config.INTERSECTION_IDS}
    st.session_state.last_quantum_telemetry = None
    st.session_state.last_qubo_meta = None
    st.session_state.last_ising_meta = None
    st.session_state.demo_running = False
    st.session_state.demo_logs = []
    st.session_state.initialized = True

# --- Title Header ---
st.markdown('<div class="main-title">Quantum-Enhanced Adaptive Urban Traffic Optimization</div>', unsafe_allow_html=True)
st.markdown('<div class="sub-title">Hybrid Quantum-Classical Traffic Optimization for Social Welfare • Powered by Featherless AI Copilot</div>', unsafe_allow_html=True)

# --- Top Status Bar ---
status_col1, status_col2, status_col3, status_col4 = st.columns(4)

with status_col1:
    emg_status = "🚨 ACTIVE IN TRANSIT" if st.session_state.corridor.is_active else ("✅ ARRIVED AT HOSPITAL" if st.session_state.corridor.completed else "IDLE")
    badge_class = "badge-emergency" if st.session_state.corridor.is_active else "badge-classical"
    st.markdown(f"**Emergency Status:** <span class='{badge_class}'>{emg_status}</span>", unsafe_allow_html=True)

with status_col2:
    mode_label = st.session_state.last_mode
    m_badge = "badge-quantum" if "Quantum" in mode_label else "badge-classical"
    st.markdown(f"**Current Mode:** <span class='{m_badge}'>{mode_label}</span>", unsafe_allow_html=True)

with status_col3:
    backend_info = st.session_state.aer_manager.get_backend_info()
    st.markdown(f"**Quantum Backend:** <span class='badge-quantum'>{backend_info['name']}</span>", unsafe_allow_html=True)

with status_col4:
    ai_status = "ACTIVE ⚡" if st.session_state.featherless_copilot.has_api_key() else "READY (Heuristic Fallback)"
    st.markdown(f"**AI Copilot:** <span class='badge-ai'>{ai_status}</span>", unsafe_allow_html=True)

st.markdown("---")

# --- Sidebar Controls ---
st.sidebar.title("🎛️ Platform Controls")

st.sidebar.subheader("1. Featherless AI Copilot")
featherless_key_input = st.sidebar.text_input(
    "Featherless API Key",
    type="password",
    value=os.getenv("FEATHERLESS_API_KEY", ""),
    placeholder="sk-...",
    help="Enter your Featherless AI subscription key. Enables real-time LLM dispatch & Quantum Explainability."
)
if featherless_key_input:
    st.session_state.featherless_copilot.api_key = featherless_key_input

featherless_model_choice = st.sidebar.selectbox(
    "Copilot LLM Model",
    [
        "meta-llama/Meta-Llama-3.1-8B-Instruct",
        "mistralai/Mistral-7B-Instruct-v0.1",
        "Qwen/Qwen2.5-7B-Instruct",
        "deepseek-ai/DeepSeek-R1-Distill-Qwen-8B"
    ],
    index=0
)
st.session_state.featherless_copilot.model = featherless_model_choice

st.sidebar.subheader("2. Quantum Configuration")
quantum_framework = st.sidebar.selectbox(
    "Quantum Framework",
    ["Qiskit Aer Simulator", "PennyLane (default.qubit)", "IBM Quantum Hardware (Optional)"],
    help="Select the quantum execution pipeline. Both use the identical QUBO/Ising formulation."
)

if quantum_framework == "IBM Quantum Hardware (Optional)":
    ibm_stat = st.session_state.ibm_manager.get_status()
    if ibm_stat['is_hardware_available']:
        st.sidebar.success(f"Connected: {ibm_stat['active_backend']}")
    else:
        st.sidebar.info(ibm_stat['status_message'])

st.sidebar.subheader("3. Visualization Options")
vis_show_vehicles = st.sidebar.checkbox("Show Microscopic Vehicles (🚗/🚙)", value=True, help="Render physical vehicles in queues and flowing waves")
vis_show_pedestrians = st.sidebar.checkbox("Show Pedestrians (🚶)", value=True, help="Render pedestrians waiting at crosswalk corners")

st.sidebar.subheader("4. Simulation Stepping")
def execute_optimization_step(mode: str, framework: str):
    """Executes a single end-to-end step under the selected controller."""
    step_res = st.session_state.simulator.step()
    emg_nodes = st.session_state.corridor.get_corridor_nodes() if st.session_state.corridor.is_active else []

    # Formulate QUBO with active policy weights
    qubo = TrafficQUBO(st.session_state.network, weights=st.session_state.custom_qubo_weights)
    Q, qubo_meta = qubo.build_qubo_matrix(emergency_nodes=emg_nodes)
    h, J, offset = qubo_to_ising(Q, num_variables=config.NUM_INTERSECTIONS)
    st.session_state.last_qubo_meta = (Q, qubo_meta)
    st.session_state.last_ising_meta = (h, J, offset)

    decisions = {}
    q_telemetry = None

    if mode == "Classical (Fixed-Time)":
        decisions = st.session_state.fixed_controller.optimize(emergency_nodes=emg_nodes)
        st.session_state.last_mode = "Classical (Fixed-Time)"
    elif mode == "Classical (Rule-Based Adaptive)":
        decisions = st.session_state.rule_controller.optimize(emergency_nodes=emg_nodes)
        st.session_state.last_mode = "Classical (Rule-Based Adaptive)"
    else:
        if "PennyLane" in framework:
            q_telemetry = st.session_state.qaoa_pennylane.optimize(h, J, offset, num_qubits=config.NUM_INTERSECTIONS)
            st.session_state.last_mode = "Quantum (PennyLane QAOA)"
        else:
            q_telemetry = st.session_state.qaoa_qiskit.optimize(h, J, offset, num_qubits=config.NUM_INTERSECTIONS)
            st.session_state.last_mode = "Quantum (Qiskit QAOA)"

        bitstring = q_telemetry['best_bitstring']
        decisions = qubo.decode_solution(bitstring)
        q_telemetry['qubo_cost'] = round(qubo.evaluate_cost(Q, bitstring), 3)
        st.session_state.last_quantum_telemetry = q_telemetry

    if st.session_state.corridor.is_active:
        decisions = st.session_state.corridor.apply_emergency_override(decisions)
        st.session_state.corridor.step()

    for node, bit in decisions.items():
        st.session_state.network.set_signal(node, bit)
    st.session_state.last_decisions = decisions

    total_q = st.session_state.simulator.get_total_queue_length()
    avg_wait = st.session_state.simulator.get_average_wait_time()
    thru = step_res['step_throughput']
    ped_demand = st.session_state.ped_mgr.get_total_pedestrian_demand()
    emg_step = st.session_state.corridor.travel_time_steps

    if "Classical" in st.session_state.last_mode:
        st.session_state.metrics_classical.record_step(
            st.session_state.step, total_q, avg_wait, thru, ped_demand, decisions, emg_step
        )
    else:
        st.session_state.metrics_quantum.record_step(
            st.session_state.step, total_q, avg_wait, thru, ped_demand, decisions, emg_step
        )

    st.session_state.step += 1

col_btn1, col_btn2 = st.sidebar.columns(2)
if col_btn1.button("▶️ Step Classical"):
    execute_optimization_step("Classical (Fixed-Time)", quantum_framework)
    st.rerun()

if col_btn2.button("⚛️ Step Quantum"):
    execute_optimization_step("Quantum QAOA", quantum_framework)
    st.rerun()

if st.sidebar.button("🤖 Step Adaptive Rule-Based"):
    execute_optimization_step("Classical (Rule-Based Adaptive)", quantum_framework)
    st.rerun()

st.sidebar.subheader("5. Dynamic City Events")
e_col1, e_col2 = st.sidebar.columns(2)
if e_col1.button("💥 Congestion Surge"):
    nodes = st.session_state.events.trigger_sudden_congestion(['B', 'E'], extra_vehicles=18)
    st.sidebar.warning(f"Congestion spike injected at {', '.join(nodes)}!")
    st.rerun()

if e_col2.button("🚗 Road Accident"):
    acc_node = st.session_state.events.trigger_accident('B', severity=0.75)
    st.sidebar.error(f"Accident at {acc_node}! Capacity slashed by 75%.")
    st.rerun()

e_col3, e_col4 = st.sidebar.columns(2)
if e_col3.button("🚧 Road Closure"):
    edge = st.session_state.events.trigger_road_closure('B', 'C')
    st.sidebar.error(f"Road {edge[0]} ↔ {edge[1]} closed!")
    st.rerun()

if e_col4.button("🚑 Dispatch Ambulance"):
    path = st.session_state.corridor.trigger_emergency('A', 'F')
    st.sidebar.success(f"Ambulance dispatched! Route: {' ➔ '.join(path)}")
    st.rerun()

if st.sidebar.button("🧹 Clear All Events"):
    st.session_state.events.clear_all_events()
    st.session_state.corridor.reset()
    st.sidebar.info("All incidents cleared.")
    st.rerun()

st.sidebar.subheader("6. Reset System")
if st.sidebar.button("🔄 Reset Everything"):
    config.set_seed()
    st.session_state.network.reset()
    st.session_state.simulator.reset()
    st.session_state.events.clear_all_events()
    st.session_state.corridor.reset()
    st.session_state.metrics_classical.reset()
    st.session_state.metrics_quantum.reset()
    st.session_state.custom_qubo_weights = config.QUBO_WEIGHTS.copy()
    st.session_state.step = 0
    st.session_state.last_mode = "None"
    st.session_state.last_quantum_telemetry = None
    st.session_state.copilot_history.clear()
    st.session_state.demo_logs.clear()
    st.sidebar.success("Reset to clean baseline.")
    st.rerun()

# --- Main Dashboard Tabs ---
tab_overview, tab_copilot, tab_quantum, tab_corridor, tab_comparison, tab_demo, tab_welfare = st.tabs([
    "🚦 Network & Vehicles Live",
    "🤖 AI Traffic Copilot (Featherless)",
    "⚛️ Quantum Optimization Engine",
    "🚑 Emergency Green Corridor",
    "📊 Classical vs Quantum Metrics",
    "🎬 1-Click End-to-End Demo",
    "🌍 Social Welfare & Ethics"
])

# ==============================================================================
# TAB 1: Network & Microscopic Vehicles Live
# ==============================================================================
with tab_overview:
    kpi_col1, kpi_col2, kpi_col3, kpi_col4, kpi_col5, kpi_col6 = st.columns(6)
    total_q = st.session_state.simulator.get_total_queue_length()
    avg_q = total_q / config.NUM_INTERSECTIONS
    avg_wait = st.session_state.simulator.get_average_wait_time()
    total_thru = st.session_state.simulator.total_vehicles_served
    ped_demand = st.session_state.ped_mgr.get_total_pedestrian_demand()

    kpi_col1.metric("Average Queue", f"{avg_q:.1f} cars", f"{total_q} total")
    kpi_col2.metric("Average Delay", f"{avg_wait:.1f} s", "per vehicle")
    kpi_col3.metric("Total Throughput", f"{total_thru}", "vehicles cleared")
    kpi_col4.metric("Pedestrians Waiting", f"{ped_demand}", "crossing demand")
    kpi_col5.metric("Est. Fuel (L)", f"{total_q * config.FUEL_IDLE_PER_VEHICLE_STEP:.2f} L", "idle consumption")
    kpi_col6.metric("Est. CO2 (kg)", f"{total_q * config.FUEL_IDLE_PER_VEHICLE_STEP * config.CO2_PER_LITER_FUEL:.2f} kg", "emissions")

    st.markdown("<br>", unsafe_allow_html=True)

    # Visualizer Row
    view_col1, view_col2 = st.columns([1, 1])

    with view_col1:
        st.subheader("🗺️ OpenStreetMap & Live Vehicles")
        st.caption("Central London Westminster Grid • Live vehicles along road polylines, 🚑 ambulance & 🏥 hospital")

        map_rendered = False
        if FOLIUM_AVAILABLE:
            try:
                folium_map = create_folium_map(
                    st.session_state.network,
                    st.session_state.corridor,
                    show_vehicles=vis_show_vehicles
                )
                st_folium(folium_map, width="100%", height=420, returned_objects=[])
                map_rendered = True
            except Exception as e:
                st.warning(f"Map offline ({e}). Using local fallback.")

        if not map_rendered:
            fallback_fig = create_network_figure(
                st.session_state.network, st.session_state.corridor,
                show_vehicles=vis_show_vehicles, show_pedestrians=vis_show_pedestrians
            )
            st.plotly_chart(fallback_fig, use_container_width=True)

    with view_col2:
        st.subheader("🏎️ Microscopic Road & Vehicle Simulation")
        st.caption("Asphalt road corridors, lane dividers, queued cars (🚗), flowing green traffic (🚙), and pedestrians (🚶)")
        net_fig = create_network_figure(
            st.session_state.network, st.session_state.corridor,
            show_vehicles=vis_show_vehicles, show_pedestrians=vis_show_pedestrians
        )
        st.plotly_chart(net_fig, use_container_width=True)

    # Telemetry Table
    st.subheader("📋 Intersection Status & Vehicle Densities")
    table_data = []
    for node_id in config.INTERSECTION_IDS:
        s = st.session_state.network.get_state(node_id)
        m = config.INTERSECTION_METADATA[node_id]
        table_data.append({
            "Node": node_id,
            "Location Name": m['name'],
            "Current Signal": "🟢 Green (Priority Flow)" if s.signal_state == 1 else "🔴 Red (Pedestrian Walk)",
            "Queue Length": f"{s.queue_length} / {s.capacity} cars",
            "Effective Capacity": s.effective_capacity,
            "Pedestrian Demand": f"{s.pedestrian_demand} 🚶",
            "Accident Severity": f"{int(s.accident_severity * 100)}%",
            "Emergency Priority": "🚨 ACTIVE" if s.emergency_priority else "None"
        })
    st.dataframe(pd.DataFrame(table_data), use_container_width=True)

# ==============================================================================
# TAB 2: AI Traffic Copilot (Featherless AI)
# ==============================================================================
with tab_copilot:
    st.subheader("🤖 Featherless AI Civic Traffic Copilot")
    st.markdown("""
    Powered by open-source LLMs hosted on **Featherless AI** (`https://api.featherless.ai/v1`).
    City operators and dispatchers can issue natural-language incident reports, request instant **Quantum Explainability (XAI)** audits,
    and autonomously calibrate multi-objective QUBO weights to match changing civic goals.
    """)

    ai_col1, ai_col2 = st.columns([1, 1])

    with ai_col1:
        st.markdown("#### 1. 🎙️ Natural Language Incident Dispatcher")
        st.caption("Describe an emergency or traffic incident in plain English:")

        sample_prompts = [
            "Major multi-vehicle accident on Whitehall. Critical cardiac ambulance dispatched from Parliament Square to St Thomas Hospital.",
            "Protest near Trafalgar Square. Close the road between B and C immediately.",
            "Sudden commuter rush at Westminster Bridge and Embankment. Heavy vehicle backlogs reported.",
            "Normal traffic restored. Clear all road incidents and reset emergency routes."
        ]
        selected_sample = st.selectbox("Quick-fill sample incident:", ["-- Select or type below --"] + sample_prompts)

        incident_input = st.text_area(
            "Incident Report / Operator Command:",
            value="" if selected_sample.startswith("--") else selected_sample,
            height=90,
            placeholder="e.g., Collision on Whitehall blocking south lanes, ambulance en route to hospital..."
        )

        if st.button("🚀 Process & Dispatch Incident via AI", type="primary"):
            if incident_input.strip():
                with st.spinner("Featherless AI is analyzing incident and extracting operational actions..."):
                    parsed_actions = st.session_state.featherless_copilot.parse_incident_report(incident_input)

                st.success(f"**AI Dispatch Report:** {parsed_actions.get('summary', 'Actions parsed successfully.')}")

                # Apply actions
                if parsed_actions.get("trigger_congestion"):
                    st.session_state.events.trigger_sudden_congestion(parsed_actions["trigger_congestion"], extra_vehicles=16)
                    st.info(f"💥 Injected congestion surge at: {', '.join(parsed_actions['trigger_congestion'])}")

                if parsed_actions.get("trigger_accident"):
                    acc_info = parsed_actions["trigger_accident"]
                    node = acc_info.get("node", "B")
                    sev = acc_info.get("severity", 0.75)
                    st.session_state.events.trigger_accident(node, severity=sev)
                    st.warning(f"🚗 Accident recorded at Intersection {node} (Severity {int(sev*100)}%)")

                if parsed_actions.get("trigger_closure"):
                    edge = parsed_actions["trigger_closure"]
                    st.session_state.events.trigger_road_closure(edge[0], edge[1])
                    st.error(f"🚧 Road {edge[0]} ↔ {edge[1]} closed to general traffic!")

                if parsed_actions.get("dispatch_ambulance"):
                    amb_info = parsed_actions["dispatch_ambulance"]
                    orig = amb_info.get("origin", "A")
                    dest = amb_info.get("destination", "F")
                    route = st.session_state.corridor.trigger_emergency(orig, dest)
                    st.success(f"🚑 Ambulance dispatched! Route: {' ➔ '.join(route)}")

                # Step quantum optimization immediately to react
                execute_optimization_step("Quantum QAOA", quantum_framework)
                st.rerun()

    with ai_col2:
        st.markdown("#### 2. 🧠 Quantum Decision Explainability (XAI)")
        st.caption("Translate complex QAOA quantum state measurements into plain-English civic justifications:")

        if st.button("🔍 Generate Quantum Decision Audit"):
            with st.spinner("Featherless AI is auditing the quantum Hamiltonian and signal decisions..."):
                q_summary = {n: st.session_state.network.get_state(n).queue_length for n in config.INTERSECTION_IDS}
                p_summary = {n: st.session_state.network.get_state(n).pedestrian_demand for n in config.INTERSECTION_IDS}
                qubo_cost = st.session_state.last_quantum_telemetry.get('qubo_cost', 0.0) if st.session_state.last_quantum_telemetry else 0.0

                xai_report = st.session_state.featherless_copilot.explain_quantum_decision(
                    step=st.session_state.step,
                    decisions=st.session_state.last_decisions,
                    queue_summary=q_summary,
                    pedestrian_summary=p_summary,
                    corridor_active=st.session_state.corridor.is_active,
                    ambulance_loc=st.session_state.corridor.get_current_ambulance_node(),
                    qubo_cost=qubo_cost
                )
                st.session_state.last_xai_explanation = xai_report

        if st.session_state.last_xai_explanation:
            st.markdown('<div class="chat-bubble">', unsafe_allow_html=True)
            st.markdown(st.session_state.last_xai_explanation)
            st.markdown('</div>', unsafe_allow_html=True)
        else:
            st.info("Click the button above to generate a real-time Quantum Explainability civic audit.")

        st.markdown("---")
        st.markdown("#### 3. 🎯 Autonomous Policy & QUBO Weight Tuning")
        policy_choice = st.selectbox(
            "Select Municipal Traffic Policy:",
            [
                "Balanced Social Welfare (Default)",
                "Peak Commuter Rush Hour (Max Throughput)",
                "Clean Air & Low Emission Zone (Min Fuel/CO2)",
                "Pedestrian Safety & Active Travel (School / Event)",
                "Maximum Emergency Transit (Life First)"
            ]
        )
        if st.button("Apply Policy Weights"):
            new_weights = st.session_state.featherless_copilot.recommend_policy_weights(policy_choice)
            st.session_state.custom_qubo_weights = new_weights
            st.success(f"Applied policy '{policy_choice}'! Active QUBO weights: {new_weights}")

# ==============================================================================
# TAB 3: Quantum Optimization Engine
# ==============================================================================
with tab_quantum:
    st.subheader("⚛️ Mathematical Formulation & Quantum Transparency")
    st.markdown("""
    The traffic signal optimization across interconnected intersections is formulated as a **Quadratic Unconstrained Binary Optimization (QUBO)** problem,
    algebraically converted to an **Ising Spin Hamiltonian** ($x_i = \\frac{1 - Z_i}{2}$), and solved using the **Quantum Approximate Optimization Algorithm (QAOA)**.
    """)

    q_col1, q_col2 = st.columns([1, 1])

    with q_col1:
        st.markdown("#### 1. QUBO Formulation ($x_i \\in \\{0, 1\\}$)")
        st.latex(r"H_{\text{QUBO}}(x) = \sum_{i} Q_{ii} x_i + \sum_{i < j} Q_{ij} x_i x_j")
        st.markdown("""
        - **$x_i = 1$**: Assign Green light to primary congested corridor.
        - **$x_i = 0$**: Assign Green light to secondary / pedestrian walk cycle.
        - **Linear Terms $Q_{ii}$**: Balance queue clearance ($-w_q Q_i$), density relief, pedestrian cross penalty ($+w_p P_i$), and emergency priority ($-w_{\text{emg}} \\times 35$).
        - **Quadratic Terms $Q_{ij}$**: Anti-conflict penalty ($+P$) to prevent adjacent gridlock, or green wave reward ($-2.5P$) along the emergency corridor.
        """)

        if st.session_state.last_qubo_meta:
            Q, meta = st.session_state.last_qubo_meta
            st.markdown("**Active QUBO Linear Coefficients ($Q_{ii}$):**")
            linear_df = pd.DataFrame([
                {"Intersection": node, "Linear Term Q_ii": meta['linear_terms'][node]['total_linear'],
                 "Queue Comp": meta['linear_terms'][node]['queue_term'],
                 "Pedestrian Comp": meta['linear_terms'][node]['ped_term'],
                 "Emergency Comp": meta['linear_terms'][node]['emg_term']}
                for node in config.INTERSECTION_IDS
            ])
            st.dataframe(linear_df, use_container_width=True)

    with q_col2:
        st.markdown("#### 2. Ising Hamiltonian ($Z_i \\in \\{+1, -1\\}$)")
        st.latex(r"H_{\text{Ising}} = \text{Offset} + \sum_{i} h_i Z_i + \sum_{i < j} J_{ij} Z_i Z_j")
        st.markdown("""
        - Using the exact substitution $x_i = \\frac{1 - Z_i}{2}$:
          - $h_i = -\\frac{Q_{ii}}{2} - \\sum_{j \\neq i} \\frac{Q_{ij}}{4}$ (Local longitudinal field)
          - $J_{ij} = \\frac{Q_{ij}}{4}$ (Two-body spin-spin coupling)
        """)

        if st.session_state.last_ising_meta:
            h, J, offset = st.session_state.last_ising_meta
            st.markdown(f"**Energy Offset:** `{offset:.4f}`")
            ising_df = pd.DataFrame([
                {"Qubit / Node": f"q_{i} ({config.INTERSECTION_IDS[i]})", "Local Field h_i": h.get(i, 0.0)}
                for i in range(config.NUM_INTERSECTIONS)
            ])
            st.dataframe(ising_df, use_container_width=True)

    st.markdown("---")
    st.subheader("🔬 QAOA Circuit & Measurement Telemetry")

    if st.session_state.last_quantum_telemetry:
        tel = st.session_state.last_quantum_telemetry
        q_m1, q_m2, q_m3, q_m4 = st.columns(4)
        q_m1.metric("Framework", tel['framework'])
        q_m2.metric("Qubits Used", tel['circuit_info']['qubits'])
        q_m3.metric("Optimal Parameters", f"γ={tel['opt_gamma']}, β={tel['opt_beta']}")
        q_m4.metric("Best Measured Bitstring", tel['best_bitstring'], f"Cost: {tel.get('qubo_cost', 0.0)}")

        st.markdown("##### Measured State Probability Distribution")
        counts = tel['counts']
        sorted_counts = sorted(counts.items(), key=lambda x: x[1], reverse=True)[:10]
        bitstrings = [item[0] for item in sorted_counts]
        shots_sampled = [item[1] for item in sorted_counts]

        bar_fig = px.bar(
            x=bitstrings, y=shots_sampled,
            labels={'x': 'Measured Bitstring (Little-Endian: [F,E,D,C,B,A])', 'y': 'Measurement Shots'},
            title="Top-10 Sampled Quantum States (QAOA Ansatz p=1)",
            color=shots_sampled, color_continuous_scale='teal'
        )
        bar_fig.update_layout(height=320, plot_bgcolor='#f8fafc')
        st.plotly_chart(bar_fig, use_container_width=True)
    else:
        st.info("No quantum execution yet. Click '⚛️ Step Quantum' in the sidebar or run the 1-Click Demo to inspect live QAOA circuits.")

# ==============================================================================
# TAB 4: Emergency Green Corridor
# ==============================================================================
with tab_corridor:
    st.subheader("🚑 Emergency Green Corridor Management")
    st.markdown("""
    When an emergency occurs, an ambulance is routed from its origin (**Parliament Square - Node A**) to the regional trauma center (**St Thomas Hospital - Node F**).
    The platform creates an active **Green Wave** by holding signals green along the transit path, clearing queues ahead of time while continuing optimal control elsewhere.
    """)

    cor_status = st.session_state.corridor.get_status()

    c_col1, c_col2, c_col3, c_col4 = st.columns(4)
    c_col1.metric("Ambulance Location", cor_status['current_location'] or ("At Hospital" if cor_status['completed'] else "Stationary at Base"))
    c_col2.metric("Destination Hospital", f"Node {cor_status['destination']} (St Thomas)")
    c_col3.metric("Corridor Route", " ➔ ".join(cor_status['route']) if cor_status['route'] else "None")
    c_col4.metric("Transit Duration", f"{cor_status['travel_time_steps']} steps", f"Disruption delay: {cor_status['disruption_delay']} s")

    st.markdown("#### Corridor Progression Timeline")
    if cor_status['route']:
        progress_val = cor_status['progress_step'] / max(1, cor_status['total_route_steps'])
        st.progress(min(1.0, progress_val))
        st.caption(f"Progress: Step {cor_status['progress_step']} of {cor_status['total_route_steps']} intersections traversed.")
    else:
        st.caption("Emergency corridor currently inactive.")

    st.markdown("---")
    st.subheader("🛡️ Road Closure Resilience")
    st.markdown("""
    If an accident or road maintenance causes a road segment to close (e.g., Road B ↔ C is blocked),
    the Emergency Corridor **automatically reroutes** the ambulance through alternative avenues (e.g. A ➔ D ➔ E ➔ F)
    and dynamically re-optimizes the green wave on the fly.
    """)

# ==============================================================================
# TAB 5: Classical vs Quantum Comparison
# ==============================================================================
with tab_comparison:
    st.subheader("📊 Comparative Benchmarking: Classical vs Hybrid Quantum")

    df_class = st.session_state.metrics_classical.to_dataframe()
    df_quant = st.session_state.metrics_quantum.to_dataframe()

    if len(df_class) > 0 or len(df_quant) > 0:
        sum_class = st.session_state.metrics_classical.get_summary()
        sum_quant = st.session_state.metrics_quantum.get_summary()

        comp_metrics = [
            ("Avg Queue Length (cars)", sum_class.get('avg_queue', 0), sum_quant.get('avg_queue', 0), True),
            ("Avg Vehicle Delay (s)", sum_class.get('avg_wait_time', 0), sum_quant.get('avg_wait_time', 0), True),
            ("Total Throughput (cars)", sum_class.get('total_throughput', 0), sum_quant.get('total_throughput', 0), False),
            ("Total Fuel Consumption (L)", sum_class.get('total_fuel_liters', 0), sum_quant.get('total_fuel_liters', 0), True),
            ("Total CO2 Emissions (kg)", sum_class.get('total_co2_kg', 0), sum_quant.get('total_co2_kg', 0), True),
            ("Social Welfare Index", sum_class.get('social_welfare_index', 0), sum_quant.get('social_welfare_index', 0), False)
        ]

        st.markdown("##### Consolidated Key Performance Indicators")
        kpi_cols = st.columns(len(comp_metrics))
        for idx, (label, val_c, val_q, lower_is_better) in enumerate(comp_metrics):
            diff = val_q - val_c
            pct = (diff / val_c * 100.0) if val_c != 0 else 0.0
            delta_str = f"{diff:+.1f} ({pct:+.1f}%)"
            delta_color = "inverse" if lower_is_better else "normal"
            kpi_cols[idx].metric(label, f"{val_q}", delta_str, delta_color=delta_color)

        st.markdown("---")

        chart_col1, chart_col2 = st.columns(2)

        with chart_col1:
            st.markdown("##### Vehicle Queue Backlog Over Time")
            fig_q = go.Figure()
            if len(df_class) > 0:
                fig_q.add_trace(go.Scatter(x=df_class['step'], y=df_class['total_queue'], mode='lines+markers', name='Classical (Fixed-Time)', line=dict(color='#e74c3c', width=2)))
            if len(df_quant) > 0:
                fig_q.add_trace(go.Scatter(x=df_quant['step'], y=df_quant['total_queue'], mode='lines+markers', name='Quantum (QAOA)', line=dict(color='#0284c7', width=3)))
            fig_q.update_layout(xaxis_title="Simulation Step", yaxis_title="Total Queued Vehicles", height=320, plot_bgcolor='#f8fafc')
            st.plotly_chart(fig_q, use_container_width=True)

        with chart_col2:
            st.markdown("##### Estimated Cumulative CO2 Emissions (kg)")
            fig_co2 = go.Figure()
            if len(df_class) > 0:
                fig_co2.add_trace(go.Scatter(x=df_class['step'], y=df_class['cumulative_co2_kg'], mode='lines', name='Classical Emissions', line=dict(color='#e74c3c', dash='dash')))
            if len(df_quant) > 0:
                fig_co2.add_trace(go.Scatter(x=df_quant['step'], y=df_quant['cumulative_co2_kg'], mode='lines', name='Quantum Emissions', line=dict(color='#0284c7', width=3)))
            fig_co2.update_layout(xaxis_title="Simulation Step", yaxis_title="Cumulative CO2 (kg)", height=320, plot_bgcolor='#f8fafc')
            st.plotly_chart(fig_co2, use_container_width=True)

    else:
        st.info("No comparative execution data recorded yet. Step simulation in Classical and Quantum modes, or click 'Run Full Demo' in Tab 6.")

# ==============================================================================
# TAB 6: 1-Click End-to-End Demo
# ==============================================================================
with tab_demo:
    st.subheader("🎬 1-Click End-to-End Hackathon Demonstration")
    st.markdown("""
    Run the complete, automated hackathon story in a single click:
    1. **Baseline Traffic**: Steps under Classical Fixed-Time control.
    2. **Sudden Congestion & Accident**: Real-time traffic spike injected.
    3. **Emergency Dispatch**: Ambulance dispatched with trauma corridor active.
    4. **Quantum QAOA Optimization**: Formulates QUBO/Ising and executes QAOA.
    5. **Green Corridor Transit**: Ambulance advances through green lights to St Thomas Hospital.
    6. **Signal Restoration**: Corridor cleared, normal adaptive welfare signals restored.
    7. **Comprehensive Benchmarking**: Final side-by-side comparison generated.
    """)

    if st.button("🚀 RUN FULL DEMO NOW", type="primary", use_container_width=True):
        demo_progress = st.progress(0.0)
        status_placeholder = st.empty()
        log_placeholder = st.empty()
        logs = []

        def log_demo(msg):
            logs.append(f"⏱️ {time.strftime('%H:%M:%S')} - {msg}")
            log_placeholder.code("\n".join(logs[-8:]), language="markdown")

        # Step 1: Baseline Classical Run
        status_placeholder.info("Stage 1/6: Running baseline traffic under Classical Fixed-Time control...")
        log_demo("Stage 1: Initializing road network and running 5 steps of Classical control...")
        for i in range(5):
            execute_optimization_step("Classical (Fixed-Time)", quantum_framework)
            demo_progress.progress((i + 1) / 30.0)
            time.sleep(0.05)

        # Step 2: Inject Congestion and Accident
        status_placeholder.warning("Stage 2/6: Injecting sudden traffic congestion spike and road accident...")
        log_demo("Stage 2: Injecting severe congestion on Whitehall (Node B) and accident...")
        st.session_state.events.trigger_sudden_congestion(['B', 'E'], extra_vehicles=15)
        st.session_state.events.trigger_accident('B', severity=0.70)
        demo_progress.progress(0.35)
        time.sleep(0.1)

        # Step 3: Dispatch Ambulance
        status_placeholder.error("Stage 3/6: 🚨 Emergency Vehicle Dispatched from Parliament Sq to Hospital!")
        log_demo("Stage 3: 🚑 Ambulance dispatched from Node A -> Hospital Node F.")
        path = st.session_state.corridor.trigger_emergency('A', 'F')
        log_demo(f"Shortest emergency path computed: {' ➔ '.join(path)}")
        demo_progress.progress(0.45)
        time.sleep(0.1)

        # Step 4: Hybrid Quantum QAOA Optimization & Corridor Progression
        status_placeholder.info("Stage 4/6: Quantum Optimization in progress (QUBO ➔ Ising ➔ QAOA)...")
        log_demo("Stage 4: Executing QAOA variational optimization on Qiskit Aer...")
        step_count = 0
        while st.session_state.corridor.is_active and step_count < 10:
            execute_optimization_step("Quantum QAOA", quantum_framework)
            step_count += 1
            demo_progress.progress(0.45 + (step_count / 10.0) * 0.4)
            log_demo(f"Ambulance moving: current intersection {st.session_state.corridor.get_current_ambulance_node()}")
            time.sleep(0.05)

        # Step 5: Hospital Arrival & Signal Restoration
        status_placeholder.success("Stage 5/6: 🎉 Ambulance arrived safely at Hospital! Restoring normal traffic signals...")
        log_demo("Stage 5: Ambulance arrived at St Thomas Hospital! Restoring balanced welfare signals.")
        demo_progress.progress(0.90)

        for _ in range(3):
            execute_optimization_step("Quantum QAOA", quantum_framework)
            time.sleep(0.05)

        # Step 6: Complete
        demo_progress.progress(1.0)
        status_placeholder.success("Stage 6/6: Complete End-to-End Demonstration Finished! Inspect comparisons below.")
        log_demo("Stage 6: Demonstration complete. Comparative analytics ready.")
        st.session_state.demo_logs = logs
        st.balloons()

    if st.session_state.demo_logs:
        st.markdown("##### Demonstration Execution Log")
        st.code("\n".join(st.session_state.demo_logs), language="markdown")

# ==============================================================================
# TAB 7: Social Welfare & Quantum Honesty
# ==============================================================================
with tab_welfare:
    st.subheader("🌍 Public Interest & Social Welfare Optimization")
    st.markdown("""
    ### Why Traffic Signal Allocation is a Civic Social Welfare Problem:
    In congested metropolitan environments, **road space is a strictly limited civic commons**.
    Traditional traffic systems make static or siloed decisions that disadvantage vulnerable road users,
    induce stop-and-go fuel burns, and delay life-saving emergency services.

    Our platform treats traffic control as a **civic utility allocation optimization**:
    1. **Emergency Priority as Human Welfare**: A medical patient's transit time is prioritized through green waves, mathematically weighted against the temporary delay to cross-traffic.
    2. **Pedestrian Equity**: Pedestrian crosswalk delays are incorporated directly into the objective, preventing high-speed vehicle favoritism from endangering or stranding pedestrians.
    3. **Environmental Justice**: Unnecessary phase flickering and stop-and-go cycles cause elevated particulate and CO2 emissions in urban cores; our switch-penalty terms explicitly mitigate this.
    """)

    st.markdown("---")
    st.subheader("⚖️ Quantum Honesty & Scientific Integrity")
    st.info("""
    **Transparency Notice**:
    - **No False Quantum Advantage**: We explicitly state that this prototype is a proof-of-concept simulation using Qiskit Aer and PennyLane classical simulator backends.
    - **Problem Scale**: For a 6-intersection urban grid (6 qubits), classical heuristics and brute-force solvers can easily solve the problem. Quantum advantage is **not claimed** for this scale.
    - **Future Value**: As urban networks expand to hundreds of intersections, the combinatorial solution space grows exponentially ($2^N$). This project demonstrates the exact mathematical formulation (QUBO $\\rightarrow$ Ising $\\rightarrow$ QAOA) required to scale onto next-generation fault-tolerant quantum processing units.
    """)
